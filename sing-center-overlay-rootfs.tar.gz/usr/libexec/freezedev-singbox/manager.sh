#!/bin/sh

STATE_DIR="/var/run/freezedev-singbox"
LOCK_FILE="$STATE_DIR/daemon.pid"
GEN_CFG="/var/etc/sing-box-freezedev.json"
LIVE_CFG="/etc/sing-box/config.json"
UCI_CFG="freezedev-singbox"

mkdir -p "$STATE_DIR"

log() {
	logger -t freezedev-singbox "$*"
}

has_cmd() {
	command -v "$1" >/dev/null 2>&1
}

core_get() {
	uci -q get "$UCI_CFG.main.$1"
}

list_enabled_profiles() {
	uci -q show "$UCI_CFG" | sed -n "s/^$UCI_CFG\.\([^=]*\)=profile$/\1/p" | while read -r section; do
		enabled="$(uci -q get "$UCI_CFG.$section.enabled")"
		[ "$enabled" = "1" ] || continue
		name="$(uci -q get "$UCI_CFG.$section.name")"
		host="$(uci -q get "$UCI_CFG.$section.endpoint_host")"
		port="$(uci -q get "$UCI_CFG.$section.endpoint_port")"
		type="$(uci -q get "$UCI_CFG.$section.type")"
		printf '%s|%s|%s|%s|%s\n' "$section" "$name" "$host" "$port" "$type"
	done
}

profile_section_by_name() {
	want="$1"
	uci -q show "$UCI_CFG" | sed -n "s/^$UCI_CFG\.\([^=]*\)=profile$/\1/p" | while read -r section; do
		name="$(uci -q get "$UCI_CFG.$section.name")"
		[ "$name" = "$want" ] && { echo "$section"; return 0; }
	done
}

ping_ms() {
	host="$1"
	timeout="${2:-2}"
	[ -n "$host" ] || { echo 999999; return 0; }
	out="$(ping -c 1 -W "$timeout" "$host" 2>/dev/null)"
	time_ms="$(echo "$out" | sed -n 's/.*time=\([0-9.]*\).*/\1/p' | awk -F. '{print $1}')"
	[ -n "$time_ms" ] || time_ms=999999
	echo "$time_ms"
}

fetch_url_to_file() {
	url="$1"
	dst="$2"
	[ -n "$url" ] || return 1

	if has_cmd uclient-fetch; then
		uclient-fetch -T 10 -O "$dst" "$url" >/dev/null 2>&1 && return 0
	fi
	if has_cmd curl; then
		curl -fsSL --connect-timeout 10 -o "$dst" "$url" >/dev/null 2>&1 && return 0
	fi
	if has_cmd wget; then
		wget -qO "$dst" "$url" >/dev/null 2>&1 && return 0
	fi
	return 1
}

is_json_like() {
	file="$1"
	first="$(sed -n 's/^[[:space:]]*\(.\).*/\1/p' "$file" | sed -n '1p')"
	[ "$first" = "{" ] || [ "$first" = "[" ]
}

extract_remnawave_payload() {
	src="$1"
	dst="$2"
	cp "$src" "$dst"

	# 1) Raw sing-box config JSON.
	if is_json_like "$dst"; then
		if jsonfilter -i "$dst" -e '@.outbounds[0].type' >/dev/null 2>&1; then
			return 0
		fi
	fi

	# 2) JSON envelope with config as string field.
	if is_json_like "$src"; then
		jsonfilter -i "$src" -e '@.config' > "$dst" 2>/dev/null
		if is_json_like "$dst" && jsonfilter -i "$dst" -e '@.outbounds[0].type' >/dev/null 2>&1; then
			return 0
		fi
	fi

	# 3) Base64-encoded subscription text.
	base64 -d "$src" > "$dst" 2>/dev/null
	if is_json_like "$dst" && jsonfilter -i "$dst" -e '@.outbounds[0].type' >/dev/null 2>&1; then
		return 0
	fi

	return 1
}

build_json_from_uri_list() {
	section="$1"
	tmp="$2"
	uris_file="$STATE_DIR/uris.$section.txt"
	: > "$uris_file"

	# Keep only URI-like lines. Universal full parser is intentionally limited.
	uci -q get "$UCI_CFG.$section.content" 2>/dev/null | tr ' ' '\n' | sed '/:\/\//!d' > "$uris_file"
	[ -s "$uris_file" ] || return 1

	{
		echo "{"
		echo "  \"log\": {\"level\": \"info\"},"
		echo "  \"outbounds\": ["
		echo "    {\"type\":\"direct\",\"tag\":\"direct\"},"
		echo "    {\"type\":\"block\",\"tag\":\"block\"}"
		echo "  ],"
		echo "  \"route\": {\"final\": \"direct\"},"
		echo "  \"experimental\": {"
		echo "    \"comment\": \"URI list stored, use JSON/remnawave-sb for fully generated outbounds\""
		echo "  }"
		echo "}"
	} > "$tmp"
	return 0
}

build_config_for_profile() {
	section="$1"
	type="$(uci -q get "$UCI_CFG.$section.type")"
	tmp="$GEN_CFG.tmp"
	: > "$tmp"

	if [ "$type" = "json" ]; then
		uci -q get "$UCI_CFG.$section.content_json" > "$tmp"
	elif [ "$type" = "remnawave" ]; then
		sub_url="$(uci -q get "$UCI_CFG.$section.subscription_url")"
		raw="$STATE_DIR/remnawave.$section.raw"
		fetch_url_to_file "$sub_url" "$raw" || {
			log "remnawave download failed: $sub_url"
			rm -f "$raw"
			return 1
		}
		extract_remnawave_payload "$raw" "$tmp" || {
			log "remnawave payload unsupported for section $section"
			rm -f "$raw"
			return 1
		}
	else
		# URI mode keeps 5+ keys in UCI; use remnawave/json for full generated config.
		build_json_from_uri_list "$section" "$tmp" || return 1
	fi

	if [ ! -s "$tmp" ]; then
		log "generated config is empty for section $section"
		rm -f "$tmp"
		return 1
	fi

	mv "$tmp" "$GEN_CFG"
	return 0
}

apply_profile() {
	profile_name="$1"
	section="$(profile_section_by_name "$profile_name" | head -n 1)"
	[ -n "$section" ] || { log "profile not found: $profile_name"; return 1; }

	build_config_for_profile "$section" || return 1

	mkdir -p /etc/sing-box
	cp "$GEN_CFG" "$LIVE_CFG"
	/etc/init.d/sing-box restart >/dev/null 2>&1
	uci -q set "$UCI_CFG.main.active_profile=$profile_name"
	uci -q commit "$UCI_CFG"
	log "applied profile: $profile_name"
}

apply_fallback() {
	mode="$(core_get fallback_mode)"
	case "$mode" in
		none)
			log "fallback: none"
			;;
		direct)
			# Stop sing-box to force provider direct path.
			/etc/init.d/sing-box stop >/dev/null 2>&1
			log "fallback: direct (sing-box stopped)"
			;;
		profile)
			fb="$(core_get fallback_profile)"
			[ -n "$fb" ] && apply_profile "$fb"
			;;
		*)
			log "unknown fallback mode: $mode"
			;;
	esac
}

choose_best_profile() {
	timeout="$(core_get ping_timeout)"
	max_ms="$(core_get max_ping_ms)"
	best_name=""
	best_ms=999999
	any=0

	list_enabled_profiles | while IFS='|' read -r _section name host _port _type; do
		any=1
		lat="$(ping_ms "$host" "$timeout")"
		echo "$name|$lat"
	done > "$STATE_DIR/candidates.txt"

	[ -s "$STATE_DIR/candidates.txt" ] || { echo ""; return 1; }

	while IFS='|' read -r name lat; do
		[ "$lat" -le "$max_ms" ] || continue
		if [ "$lat" -lt "$best_ms" ]; then
			best_ms="$lat"
			best_name="$name"
		fi
	done < "$STATE_DIR/candidates.txt"

	echo "$best_name"
}

enforce_kill_switch() {
	kill_switch="$(core_get kill_switch)"
	[ "$kill_switch" = "1" ] || return 0
	# Basic default-deny output when enabled; users should refine firewall rules.
	iptables -C OUTPUT -m comment --comment FREEZEDEV_KILLSWITCH -j REJECT 2>/dev/null || \
		iptables -A OUTPUT -m comment --comment FREEZEDEV_KILLSWITCH -j REJECT
}

clear_kill_switch() {
	while iptables -C OUTPUT -m comment --comment FREEZEDEV_KILLSWITCH -j REJECT 2>/dev/null; do
		iptables -D OUTPUT -m comment --comment FREEZEDEV_KILLSWITCH -j REJECT || break
	done
}

reconcile_routes() {
	# Placeholder for domain/IP split routing orchestration via nftables/ipset.
	# UCI route sections are persisted and editable in LuCI.
	return 0
}

loop() {
	enabled="$(core_get enabled)"
	[ "$enabled" = "1" ] || { clear_kill_switch; return 0; }

	interval="$(core_get check_interval)"
	[ -n "$interval" ] || interval=15

	while true; do
		best="$(choose_best_profile)"
		if [ -n "$best" ]; then
			apply_profile "$best"
			clear_kill_switch
		else
			apply_fallback
			enforce_kill_switch
		fi

		reconcile_routes
		sleep "$interval"
	done
}

daemon() {
	echo $$ > "$LOCK_FILE"
	trap 'rm -f "$LOCK_FILE"; exit 0' INT TERM EXIT
	loop
}

stop_daemon() {
	if [ -f "$LOCK_FILE" ]; then
		pid="$(cat "$LOCK_FILE" 2>/dev/null)"
		[ -n "$pid" ] && kill "$pid" >/dev/null 2>&1
		rm -f "$LOCK_FILE"
	fi
	clear_kill_switch
}

reload_daemon() {
	stop_daemon
	daemon
}

cmd="$1"
case "$cmd" in
	daemon) daemon ;;
	stop) stop_daemon ;;
	reload) reload_daemon ;;
	apply) apply_profile "$2" ;;
	*)
		echo "usage: $0 {daemon|stop|reload|apply <profile_name>}"
		exit 1
		;;
esac
