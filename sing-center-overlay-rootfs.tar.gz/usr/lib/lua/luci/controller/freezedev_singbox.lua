module("luci.controller.freezedev_singbox", package.seeall)

function index()
	if not nixio.fs.access("/etc/config/freezedev-singbox") then
		return
	end

	entry({"admin", "services", "freezedev-singbox"}, alias("admin", "services", "freezedev-singbox", "settings"), _("FreezeDev Sing-box"), 60)
	entry({"admin", "services", "freezedev-singbox", "settings"}, cbi("freezedev_singbox/settings"), _("Settings"), 10)
	entry({"admin", "services", "freezedev-singbox", "profiles"}, cbi("freezedev_singbox/profiles"), _("Profiles"), 20)
	entry({"admin", "services", "freezedev-singbox", "routes"}, cbi("freezedev_singbox/routes"), _("Routes"), 30)
end
