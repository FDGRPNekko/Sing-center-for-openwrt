local m, s, o

m = Map("freezedev-singbox", "Routing rules", "Split traffic by domains/IPs: tunnel or direct.")

s = m:section(TypedSection, "route", "Rules")
s.anonymous = true
s.addremove = true
s.template = "cbi/tblsection"

o = s:option(Flag, "enabled", "Enabled")
o.rmempty = false

o = s:option(Value, "name", "Rule name")
o.placeholder = "streaming-via-tunnel"
o.rmempty = false

o = s:option(ListValue, "target_type", "Target type")
o:value("domain", "domain")
o:value("ipcidr", "ip/cidr")
o.default = "domain"

o = s:option(Value, "target", "Target")
o.placeholder = "example.com or 10.8.0.0/24"
o.rmempty = false

o = s:option(ListValue, "policy", "Policy")
o:value("tunnel", "tunnel")
o:value("direct", "direct/provider")
o.default = "tunnel"

return m
