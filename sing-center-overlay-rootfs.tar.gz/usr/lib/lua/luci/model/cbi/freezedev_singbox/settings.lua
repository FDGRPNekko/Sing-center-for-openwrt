local m, s, o

m = Map("freezedev-singbox", "FreezeDev Sing-box Manager", "Global options for sing-box orchestration. Author: FreezeDev")

s = m:section(NamedSection, "main", "core", "Core")
s.anonymous = true

o = s:option(Flag, "enabled", "Enable manager")
o.rmempty = false

o = s:option(Flag, "kill_switch", "Kill switch")
o.description = "Block outbound traffic when no working profile is available."

o = s:option(ListValue, "fallback_mode", "Fallback")
o:value("none", "none")
o:value("profile", "selected profile")
o:value("direct", "direct (ISP)")

o = s:option(Value, "fallback_profile", "Fallback profile name")
o.placeholder = "Vless_server1"
o:depends("fallback_mode", "profile")

o = s:option(Value, "check_interval", "Check interval (seconds)")
o.datatype = "uinteger"
o.default = 15

o = s:option(Value, "ping_timeout", "Ping timeout (seconds)")
o.datatype = "uinteger"
o.default = 2

o = s:option(Value, "max_ping_ms", "Max healthy ping (ms)")
o.datatype = "uinteger"
o.default = 700

o = s:option(DummyValue, "active_profile", "Current active profile")
o.rawhtml = true
function o.cfgvalue(self, section)
	local v = m.uci:get("freezedev-singbox", "main", "active_profile") or "-"
	return "<strong>" .. luci.util.pcdata(v) .. "</strong>"
end

return m
