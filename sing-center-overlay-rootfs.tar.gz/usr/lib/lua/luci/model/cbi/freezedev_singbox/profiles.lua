local m, s, o

m = Map("freezedev-singbox", "Profiles", "Add multiple profiles/keys (5+ supported) and full config JSON.")

s = m:section(TypedSection, "profile", "Profile list")
s.anonymous = true
s.addremove = true
s.template = "cbi/tblsection"

o = s:option(Flag, "enabled", "Enabled")
o.rmempty = false

o = s:option(Value, "name", "Profile name")
o.placeholder = "Vless_server1"
o.rmempty = false

o = s:option(ListValue, "type", "Input type")
o:value("uri", "URI / subscription keys")
o:value("json", "Full JSON config")
o:value("remnawave", "Remnawave subscription")
o.default = "uri"

o = s:option(DynamicList, "content", "Keys / URIs")
o.description = "Paste multiple keys/subscriptions (vless://, hy2://, ss:// and others)."
o:depends("type", "uri")

o = s:option(TextValue, "content_json", "Full sing-box JSON")
o.rows = 18
o.wrap = "off"
o:depends("type", "json")
function o.cfgvalue(self, section)
	return m.uci:get("freezedev-singbox", section, "content_json") or ""
end
function o.write(self, section, value)
	m.uci:set("freezedev-singbox", section, "content_json", value)
end

o = s:option(Value, "subscription_url", "Remnawave URL")
o.placeholder = "https://example.com/sub/sing-box"
o:depends("type", "remnawave")

o = s:option(Value, "endpoint_host", "Health-check host")
o.placeholder = "1.1.1.1"

o = s:option(Value, "endpoint_port", "Health-check port")
o.datatype = "port"
o.default = 443

return m
